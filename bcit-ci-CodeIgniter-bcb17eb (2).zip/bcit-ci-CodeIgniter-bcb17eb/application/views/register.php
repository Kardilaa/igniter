<!DOCTYPE html>
<html lang="en">
<head>
    <title></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" 
    integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link href="style.css" rel="stylesheet"> 
</head>
<body style="background:green">
    <div style="padding: 50px;">
    <a href="<?php echo site_url('signup/home') ?>" > </a>
       
        <div class="container mt-3">
        <div class="row" >
        <div class="col-md-6 offset-md-3">
        <div class="card my-6">
            <h2 class="mb-3 mt-4 text-center" style="color:rgb(61, 61, 61);">Tambah Siswa</h2>
              <div class="mb-3 mt-3 text-center">
                Nama : <br>
                <input class="rounded-3 border-light" type="text" name="nama" placeholder="masukan Nama anda" 
                style="width: 300px;">
              </div>
              <div class="mb-3 mt-3 text-center">
                username : <br>
                <input class="rounded-3 border-light" type="text" name="username" placeholder="masukan Username anda" 
                style="width: 300px;">
              </div>
              <div class="mb-3 mt-3 text-center">
                password : <br>
                <input class="rounded-3 border-light" type="text" name="password" placeholder="masukan password anda" 
                style="width: 300px;">
              </div>
              <div class="mb-3 mt-3 text-center">
                email : <br>
                <input class="rounded-3 border-light" type="text" name="email" placeholder="masukan email anda" 
                style="width: 300px;">
                <div class="mb-3 mt-3 text-center">
                ID : <br>
                <input class="rounded-3 border-light" type="text" name="no_hp" placeholder="masukan ID anda" 
                style="width: 300px;">
              </div>
              <div class="text-center mt-3"> 
                <button type="submit" class="btn btn-success px-3 mb-3" style="width: 300px;"> <a href="<?php echo site_url('signup/home') ?>" >Simpan</button> <br></a>
                
                </div>
              </div>
              </div>
            </form>
</body>
</html>
