<?php

$db = mysqli_connect("localhost","root","","catatan_perjalanan");

$result = mysqli_query($db, "SELECT * FROM catatan_perjalanan");
if(isset($_GET['id'])){
  
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  
    <meta charset="UTF-8">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    
</head>
<body style="background:green">
<div class="container mt-5">
    <h2>catatan perjalanan</h2>
</div>
<div class="card my-4 mt-3">
  <div class="d-grip gap-2 col-12 mt-2">
  <table class="table table-light table-hover table-borderless">
  <thead>
    <tr style="text-align:center;">
      <th scope="col">No</th>
      <th scope="col">Tanggal</th>
      <th scope="col">Waktu</th>
      <th scope="col">Lokasi</th>
      <th scope="col">Suhu Tubuh</th>
    </tr>
  </thead> 
  <tbody>
</body>
</html>