<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class signup extends CI_Controller {	
	public function login(){
		$this->load->view('login');
}
public function home(){

	$this->load->view('home');
}
public function register(){

	$this->load->view('register');
}
//public function getsiswa(){

	//$this->load->database();
	//$data['siswa'] = $this->db->get('siswa')->result_array();
	//$this->load->view('siswa/home',$data);
//}
//function insertsiswa(){
	//$this->load->database();
	//$data = aray{
		//'username'=>'zalfa',
		//'nama'=>'sabrina',
		//'password'=>'123',
	//};
	//$this->db->insert('siswa', $data);
//}
}